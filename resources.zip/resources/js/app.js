console.log('Tailwind fix kit carregado');

document.addEventListener("DOMContentLoaded", () => {
    const sidebar = document.querySelector(".sidebar");
    const toggleBtn = document.querySelector("#sidebar-toggle");
    const iconMenu = document.querySelector("#icon-menu");
    const iconClose = document.querySelector("#icon-close");

    if (sidebar && toggleBtn) {
        toggleBtn.addEventListener("click", () => {
            sidebar.classList.toggle("hidden");
            iconMenu.classList.toggle("hidden");
            iconClose.classList.toggle("hidden");
        });
    }
});

(function () {
  const STORAGE_KEY = 'bscn_sidebar_state'; // 'expanded' | 'collapsed'
  const sidebar = document.querySelector('.sidebar');
  const content = document.querySelector('#app-content');
  const overlay = document.querySelector('#sidebar-overlay');
  const toggleBtn = document.querySelector('#sidebar-toggle');
  const iconMenu = document.querySelector('#icon-menu');
  const iconClose = document.querySelector('#icon-close');

  if (!sidebar || !content) return;

  const isDesktop = () => window.matchMedia('(min-width: 768px)').matches;

  // Aplica estado guardado (apenas em desktop)
  const applyPersistedState = () => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (isDesktop()) {
      if (saved === 'collapsed') {
        sidebar.classList.add('hidden');
        content.classList.add('content--collapsed');
        iconMenu && iconMenu.classList.remove('hidden');
        iconClose && iconClose.classList.add('hidden');
      } else {
        sidebar.classList.remove('hidden');
        content.classList.remove('content--collapsed');
        iconMenu && iconMenu.classList.add('hidden');
        iconClose && iconClose.classList.remove('hidden');
      }
    } else {
      // mobile começa fechado (off-canvas)
      sidebar.classList.add('sidebar--mobile-hidden');
      sidebar.classList.remove('hidden');
      iconMenu && iconMenu.classList.remove('hidden');
      iconClose && iconClose.classList.add('hidden');
      overlay && overlay.classList.remove('sidebar-overlay--active');
    }
  };

  const openMobile = () => {
    sidebar.classList.remove('sidebar--mobile-hidden');
    sidebar.classList.add('sidebar--mobile-visible');
    overlay && overlay.classList.add('sidebar-overlay--active');
    iconMenu && iconMenu.classList.add('hidden');
    iconClose && iconClose.classList.remove('hidden');
  };

  const closeMobile = () => {
    sidebar.classList.add('sidebar--mobile-hidden');
    sidebar.classList.remove('sidebar--mobile-visible');
    overlay && overlay.classList.remove('sidebar-overlay--active');
    iconMenu && iconMenu.classList.remove('hidden');
    iconClose && iconClose.classList.add('hidden');
  };

  const toggleDesktop = () => {
    const collapsed = sidebar.classList.toggle('hidden');
    content.classList.toggle('content--collapsed', collapsed);
    // ícones
    if (collapsed) {
      iconMenu && iconMenu.classList.remove('hidden');
      iconClose && iconClose.classList.add('hidden');
      localStorage.setItem(STORAGE_KEY, 'collapsed');
    } else {
      iconMenu && iconMenu.classList.add('hidden');
      iconClose && iconClose.classList.remove('hidden');
      localStorage.setItem(STORAGE_KEY, 'expanded');
    }
  };

  // Evento do botão
  toggleBtn && toggleBtn.addEventListener('click', () => {
    if (isDesktop()) toggleDesktop();
    else {
      // mobile: abre/fecha off-canvas
      if (sidebar.classList.contains('sidebar--mobile-hidden')) openMobile();
      else closeMobile();
    }
  });

  // Click no overlay fecha no mobile
  overlay && overlay.addEventListener('click', closeMobile);

  // Reagir a resize (muda entre mobile/desktop mantendo consistência)
  window.addEventListener('resize', () => {
    applyPersistedState();
  });

  // Estado inicial
  document.addEventListener('DOMContentLoaded', applyPersistedState);
  applyPersistedState();
})();