import.meta.glob(['../images/**', '../fonts/**']);
