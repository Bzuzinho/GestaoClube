<!DOCTYPE html>
<html lang="pt">
<head>
    @vite('resources/css/app.scss')
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Benedita Sport Club Natação</title>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

    <style>
    /* === Variáveis === */
    :root {
        --gestao-bg: rgba(255, 255, 255, 0);
        --gestao-hover-bg: rgba(52, 58, 64, 0.33);
        --gestao-color: #fff;
        --gestao-hover-color: #fff;
        --gestao-font-weight: 600;
        --gestao-font-size: 15px;
        --gestao-padding: 6px 14px;
        --gestao-border-radius: 4px;
    }

    /* === Cabeçalho e Branding === */
    .header-container { position: relative; }
    .logo-container {
        position: absolute;
        top: 5px;
        left: 10px;
        z-index: 10;
    }
    .logo-container img {
        height: 70px;
        width: auto;
        display: block;
    }
    .blue-bar {
        background-color: rgb(4, 50, 119);
        height: 45px;
        display: flex;
        align-items: center;
        padding: 0 20px 0 90px;
        color: white;
        justify-content: space-between;
    }
    .yellow-bar {
        background-color: rgb(251, 255, 8);
        height: 35px;
        display: flex;
        align-items: center;
        padding: 0 20px 0 100px;
        justify-content: space-between;
    }
    .yellow-bar nav {
        display: flex;
        align-items: center;
        gap: 20px;
    }
    .yellow-bar nav a {
        color: black;
        text-decoration: none;
        font-weight: 400;
    }
    .yellow-bar nav a:hover {
        text-decoration: underline;
    }

    /* === Menus e Dropdowns === */

    .yellow-bar .dropdown .btn-gestao {
    color: #000 !important;
    }
    
       
    .btn-gestao {
        background-color: var(--gestao-bg);
        color: var(--gestao-color);
        font-weight: var(--gestao-font-weight);
        padding: var(--gestao-padding);
        border-radius: var(--gestao-border-radius);
        font-size: var(--gestao-font-size);
        border: none;
    }
    .btn-gestao:hover {
        background-color: var(--gestao-hover-bg);
        color: var(--gestao-hover-color);
    }
    .dropdown-menu-gestao {
        background-color: #f8f9fa;
        border-radius: 6px;
        border: 1px solid #ccc;
        min-width: 150px;
        padding: 0;
        margin-top: 5px;
    }
    .dropdown-menu-gestao .menu-principal {
        font-weight: 600;
        padding-left: 14px;
        color: #212529;
        background-color: #f8f9fa;
    }
    .dropdown-menu-gestao .submenu-item {
        padding-left: 40px !important;
        background-color: #f1f1f1 !important;
        color: #495057 !important;
        font-weight: normal !important;
        font-size: 14px !important;
    }
    .dropdown-menu-gestao li {
        margin: 0;
    }
    .dropdown-menu-gestao .dropdown-item:hover {
        background-color: #e9ecef;
        color: #000;
    }
    .dropdown-menu-user {
        background-color: #f8f9fa;
        border-radius: 6px;
        border: 1px solid #ccc;
        min-width: 150px;
        padding: 0;
        overflow: hidden;
    }
    .dropdown-menu-user .dropdown-item {
        font-size: 14px;
        font-weight: 500;
        color: #212529;
        padding: 6px 14px;
        white-space: nowrap;
        width: 100%;
        box-sizing: border-box;
    }
    .dropdown-menu-user .dropdown-item:hover {
        background-color: #e9ecef;
        color: #000;
    }
    .user-avatar {
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .user-avatar img {
        height: 30px;
        width: 30px;
        object-fit: cover;
        border-radius: 50%;
    }
    .user-avatar span {
        font-weight: 600;
        color: white;
    }

    /* === Tabelas === */
    .table.table-sm th,
    .table.table-sm td {
        padding: 0.35rem 0.5rem;
        font-size: 13px;
        vertical-align: middle;
    }
    .table thead th {
        background-color: #e9ecef;
        font-weight: 500;
        font-size: 12px;
        text-transform: uppercase;
        color: #333;
        padding: 0.35rem 0.5rem;
    }
    .table .btn,
    .table .badge {
        font-size: 12px;
        padding: 2px 6px;
    }
    .table-compact {
        font-size: 13px;
    }
    .table td.acoes {
        text-align: center;
        white-space: nowrap;
    }
    .table-header {
        background-color: #0d6efd;
        color: #fff;
        padding: 6px 12px;
        font-size: 14px;
        font-weight: 600;
        border-top-left-radius: 6px;
        border-top-right-radius: 6px;
        margin-bottom: 0;
        display: inline-block;
    }

    /* === Botões compactos === */
    .btn-compact {
        font-size: 13px;
        padding: 4px 10px;
        font-weight: 500;
        border-radius: 4px;
    }
    .btn-compact i {
        font-size: 14px;
        margin-right: 4px;
    }

    /* === Footer === */
    footer {
        background-color: #f1f1f1;
        padding: 20px 0;
        text-align: center;
        color: #666;
        font-size: 14px;
        border-top: 1px solid #ccc;
        margin-top: 20px;
    }
    .footer-social a {
        color: #666;
        margin: 0 10px;
        font-size: 16px;
    }
    .footer-social a:hover {
        color: #000;
    }

    /* === Tabs === */
    .nav-tabs .nav-link.active {
        background-color: #0d6efd;
        color: #fff;
        border-color: #dee2e6 #dee2e6 #fff;
    }
    .nav-tabs .nav-link {
        color: #0d6efd;
    }
    .tab-content {
        background-color: #f8f9fa;
        border-radius: 0 0 .375rem .375rem;
        padding: 1rem;
    }
    .card-header h5 { margin: 0; }
    </style>
</head>
<body>
<header class="header-container">
    <div class="logo-container">
        <img src="/images/logo.png" alt="Logo BSCN">
    </div>

    <div class="blue-bar">
        <h4 class="m-0 ps-2">Benedita Sport Club Natação</h4>

        <div class="dropdown">
            @auth
                <a class="btn btn-gestao dropdown-toggle user-avatar" href="#" role="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    @if(Auth::user()->profile_photo_path)
                        <img src="{{ asset('storage/' . Auth::user()->profile_photo_path) }}" alt="Foto de Perfil">
                    @else
                        <i class="bi bi-person-circle"></i>
                    @endif
                    <span>{{ explode(' ', Auth::user()->name)[0] }} {{ explode(' ', Auth::user()->name)[count(explode(' ', Auth::user()->name)) - 1] }}</span>
                </a>
                <ul class="dropdown-menu dropdown-menu-end dropdown-menu-user" aria-labelledby="userDropdown">
                    <li><a class="dropdown-item" href="{{ route('utilizadores.edit', auth()->id()) }}">Ver Perfil</a></li>
                    <li>
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                            <button type="submit" class="dropdown-item">Terminar Sessão</button>
                        </form>
                    </li>
                </ul>
            @else
                <a class="btn btn-gestao dropdown-toggle" href="#" role="button" id="guestDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="bi bi-person-circle"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-end dropdown-menu-user" aria-labelledby="guestDropdown">
                    <li><a class="dropdown-item" href="{{ route('login') }}">Iniciar Sessão</a></li>
                </ul>
            @endauth
        </div>
    </div>

    <div class="yellow-bar">
        <nav class="d-flex align-items-center">
            <a href="{{ route('home') }}">Início</a>
            <a href="#">O Clube</a>
            <a href="#">Área Desportiva</a>
            <div class="dropdown">
                <button class="btn btn-gestao dropdown-toggle" type="button" id="dropdownCalendario" data-bs-toggle="dropdown" aria-expanded="false">
                    </i> Calendário
                </button>
                <ul class="dropdown-menu dropdown-menu-gestao" aria-labelledby="dropdownCalendario">
                    <li><a class="dropdown-item menu-principal" href="{{ route('eventos.publicos') }}">Ver Calendário</a></li>
                    @auth
                        @if(Auth::user()->hasRole(['administrador', 'treinador']))
                            <li><a class="dropdown-item menu-principal" href="{{ route('eventos.index') }}">Lista de Eventos</a></li>
                        @endif
                    @endauth
                </ul>
            </div>
            <a href="#">Notícias</a>
            <a href="#">Contactos</a>

            @auth
                @if(Auth::user() && Auth::user()->hasRole('administrador'))
                    <div class="dropdown">
                        <a class="btn btn-gestao dropdown-toggle" href="#" role="button" id="gestaoDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            Gestão
                        </a>
                        <ul class="dropdown-menu dropdown-menu-gestao" aria-labelledby="gestaoDropdown">
                            <li><a class="dropdown-item menu-principal" href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                            <li><a class="dropdown-item menu-principal" href="{{ route('admin.membros.index') }}">Gestão de Membros</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><span class="dropdown-item menu-principal">Gestão Financeira</span></li>
                            <li><a class="dropdown-item submenu-item" href="{{ route('faturas.index') }}">Faturas</a></li>
                            <li><a class="dropdown-item submenu-item" href="{{ route('faturas.mensalidades') }}">Mensalidades</a></li>
                        </ul>
                    </div>
                @endif
            @endauth
        </nav>
    </div>
</header>

<main class="container my-4">
    @yield('content')
</main>

<footer class="text-center small py-4 text-muted bg-light border-top">
    <p class="mb-1">© {{ date('Y') }} Benedita Sport Club Natação. Todos os direitos reservados.</p>
    <div>
        <a href="#" class="text-muted me-2"><i class="bi bi-facebook"></i></a>
        <a href="#" class="text-muted me-2"><i class="bi bi-instagram"></i></a>
        <a href="#" class="text-muted"><i class="bi bi-youtube"></i></a>
    </div>
</footer>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
@vite('resources/js/app.js')
@stack('scripts')
</body>
</html>
