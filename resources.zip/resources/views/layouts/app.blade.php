<!doctype html>
<html lang="pt">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>@yield('title', 'BSCN')</title>
  @vite(['resources/css/app.scss','resources/js/app.js'])
</head>
<body class="bg-light">

  {{-- HEADER COMPACTO --}}
  <header class="bscn-header">
    <button id="sidebar-toggle" class="bscn-toggle" aria-label="Alternar menu">
      {{-- ícones: um para "abrir" e outro para "fechar"; o JS alterna hidden --}}
      <svg id="icon-menu" class="icon" viewBox="0 0 24 24"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
      <svg id="icon-close" class="icon hidden" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>
    </button>
    <h1 class="page-title">@yield('page_title', $pageTitle ?? 'Painel de Gestão')</h1>

    <div class="ms-auto d-flex align-items-center gap-2">
      @yield('header_actions')
    </div>
  </header>

  {{-- OVERLAY (apenas mobile) --}}
  <div id="sidebar-overlay"></div>

  {{-- SHELL: SIDEBAR + CONTEÚDO (fica por baixo do header) --}}
  <div class="bscn-shell">
    <aside class="sidebar">
      {{-- O TEU MENU AQUI. Envolve textos em <span class="menu-text"> para poderes esconder se quiseres. --}}
      <nav class="menu">
        <a href="{{ route('dashboard') }}" class="menu-item">
          <i class="bi bi-speedometer2"></i> <span class="menu-text">Dashboard</span>
        </a>
        {{-- ...resto do menu... --}}
      </nav>
    </aside>

    <main id="app-content" class="bscn-content">
      @yield('content')
    </main>
  </div>

</body>
</html>
