@extends('layouts.app')
@section('title','Importação de Pessoas')

@section('content')
<div class="page-card">
  <div class="page-toolbar">
    <h2 class="page-title">Importação (stub)</h2>
    <div class="page-actions">
      <x-button variant="primary">Exemplo</x-button>
    </div>
  </div>
  <p>Esta é uma página temporária para validação de rotas.</p>
</div>
@endsection
