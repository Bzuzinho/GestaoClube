
@extends('layouts.app')
@section('title','Dashboard')
@section('crumb','Dashboard')

@section('content')
<div class="section">
  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
    <div class="kpi"><div><div class="meta">Atletas Ativos</div><div class="value">124</div><div class="trend">+4 este mês</div></div><div class="icon">👟</div></div>
    <div class="kpi"><div><div class="meta">Faturas Pendentes</div><div class="value">38</div><div class="trend">12 vencem esta semana</div></div><div class="icon">💶</div></div>
    <div class="kpi"><div><div class="meta">Eventos Próximos</div><div class="value">6</div><div class="trend">3 competições</div></div><div class="icon">📅</div></div>
    <div class="kpi"><div><div class="meta">Mensalidades Pagas</div><div class="value">92%</div><div class="trend">objetivo 95%</div></div><div class="icon">✅</div></div>
    <div class="kpi"><div><div class="meta">Treinos Hoje</div><div class="value">4</div><div class="trend">manhã + tarde</div></div><div class="icon">🏊</div></div>
    <div class="kpi"><div><div class="meta">Notícias</div><div class="value">12</div><div class="trend">publicadas</div></div><div class="icon">📰</div></div>
  </div>
</div>

<div class="section">
  <div class="table-panel">
    <div class="header">
      <h2 class="text-lg font-semibold">Pendentes Recentes</h2>
      <div class="flex items-center gap-2">
        <div class="toolbar-filters">
          <span class="chip chip-active">Tudo</span>
          <span class="chip">Mensalidades</span>
          <span class="chip">Eventos</span>
        </div>
        <button class="btn-primary">Ver Todos</button>
      </div>
    </div>
    <table class="table-compact">
      <thead><tr><th>Nome</th><th>Categoria</th><th>Data</th><th>Estado</th></tr></thead>
      <tbody>
        <tr><td>João Silva</td><td>Mensalidade</td><td>09/10/2025</td><td><span class="text-red-600">Em atraso</span></td></tr>
        <tr><td>Maria Costa</td><td>Evento</td><td>10/10/2025</td><td><span class="text-yellow-700">Pendente</span></td></tr>
      </tbody>
    </table>
  </div>
</div>
@endsection
