<header class="topbar">
  <div>
    <div class="breadcrumbs">BSCN / @yield('crumb','Dashboard')</div>
    <h1 class="page-title">@yield('title','Dashboard')</h1>
  </div>
  {{-- (removidos: pesquisa e dropdown do utilizador) --}}
</header>
