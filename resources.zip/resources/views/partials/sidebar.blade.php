<aside class="sidebar-dark">
  {{-- 1) TOPO – Logotipo + títulos --}}
  <div class="sidebar-top">
    <div class="flex items-center gap-3">
      <div class="h-12 w-12 rounded-lg overflow-hidden ring-1 ring-white/20 bg-white/10 flex items-center justify-center">
        {{-- Logo do clube --}}
        <img src="{{ asset('images/logo-clube.png') }}" alt="Logo" class="h-12 w-12 object-cover">
      </div>
      <div>
        <div class="club-title">Benedita Sport Club</div>
        <div class="club-sub">sistema de gestão</div>
      </div>
    </div>
  </div>

  {{-- 2) MEIO – Menu Principal --}}
  <div class="sidebar-middle">
    <div class="menu-heading">Menu Principal</div>
    <nav class="menu-list">

      <a href="{{ route('dashboard') }}"
         class="menu-link {{ request()->routeIs('dashboard') ? 'menu-active' : '' }}">
        {{-- ícone: home --}}
        <svg class="h-5 w-5 text-white" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>
        </svg>
        <span>Dashboard</span>
      </a>

      <a href="{{ route('pessoas.utilizadores.index') }}"
         class="menu-link {{ request()->routeIs('pessoas.*') ? 'menu-active' : '' }}">
        {{-- ícone: users --}}
        <svg class="h-5 w-5 text-white" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M16 14a4 4 0 1 1 0-8 4 4 0 0 1 0 8ZM6 16a4 4 0 1 1 6.4 3.2A9 9 0 0 1 3 21v-1a4 4 0 0 1 3-3Z"/>
        </svg>
        <span>Gestão de Pessoas</span>
      </a>

      <a href="{{ route('atividades.eventos.index') }}"
         class="menu-link {{ request()->routeIs('atividades.*') ? 'menu-active' : '' }}">
        {{-- ícone: activity --}}
        <svg class="h-5 w-5 text-white" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M3 12h4l2-6 4 12 2-6h6"/>
        </svg>
        <span>Atividades</span>
      </a>

      <a href="{{ route('financeiro.faturas.index') }}"
         class="menu-link {{ request()->routeIs('financeiro.*') ? 'menu-active' : '' }}">
        {{-- ícone: banknotes --}}
        <svg class="h-5 w-5 text-white" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <rect x="3" y="6" width="18" height="12" rx="2" />
          <circle cx="12" cy="12" r="2.5"/>
        </svg>
        <span>Financeiro</span>
      </a>

      <a href="{{ route('inventario.materiais.index') }}"
         class="menu-link {{ request()->routeIs('inventario.*') ? 'menu-active' : '' }}">
        {{-- ícone: cube --}}
        <svg class="h-5 w-5 text-white" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path d="M12 2 21 7l-9 5-9-5 9-5Z"/><path d="M21 7v10l-9 5-9-5V7"/>
        </svg>
        <span>Inventário</span>
      </a>

      <a href="{{ route('comunicacao.campanhas.index') }}"
         class="menu-link {{ request()->routeIs('comunicacao.*') ? 'menu-active' : '' }}">
        {{-- ícone: megaphone --}}
        <svg class="h-5 w-5 text-white" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path d="M3 11v2a3 3 0 0 0 3 3h2"/><path d="M15 11v2"/><path d="M21 8v8l-10 3V5l10 3Z"/>
        </svg>
        <span>Comunicação</span>
      </a>

      <a href="{{ route('relatorios.financeiros') }}"
         class="menu-link {{ request()->routeIs('relatorios.*') ? 'menu-active' : '' }}">
        {{-- ícone: chart bar --}}
        <svg class="h-5 w-5 text-white" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path d="M3 21V4"/><rect x="6" y="10" width="3" height="7"/><rect x="11" y="6" width="3" height="11"/><rect x="16" y="13" width="3" height="4"/>
        </svg>
        <span>Relatórios</span>
      </a>

      <a href="{{ route('config.associacao.index') }}"
         class="menu-link {{ request()->routeIs('config.*') ? 'menu-active' : '' }}">
        {{-- ícone: settings --}}
        <svg class="h-5 w-5 text-white" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path d="M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z"/>
          <path d="M19.4 15a1 1 0 0 0 .2 1.1l.1.1a2 2 0 0 1-2.8 2.8l-.1-.1a1 1 0 0 0-1.1-.2 1 1 0 0 0-.6.9V20a2 2 0 0 1-4 0v-.2a1 1 0 0 0-.6-.9 1 1 0 0 0-1.1.2l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1 1 0 0 0 .2-1.1 1 1 0 0 0-.9-.6H4a2 2 0 0 1 0-4h.2a1 1 0 0 0 .9-.6 1 1 0 0 0-.2-1.1l-.1-.1A2 2 0 0 1 7.6 4l.1.1a1 1 0 0 0 1.1.2H9a1 1 0 0 0 .6-.9V4a2 2 0 0 1 4 0v.2a1 1 0 0 0 .6.9h.2a1 1 0 0 0 1.1-.2l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1 1 0 0 0-.2 1.1v.2a1 1 0 0 0 .9.6H20a2 2 0 0 1 0 4h-.2a1 1 0 0 0-.9.6Z"/>
        </svg>
        <span>Configurações</span>
      </a>

    </nav>
  </div>

  {{-- 3) FUNDO – Perfil + logout --}}
  <div class="sidebar-bottom">
    <div class="user-card">
      <div class="avatar">
        @php $u = Auth::user(); @endphp
        @if(isset($u) && method_exists($u,'avatar_url') && $u->avatar_url)
          <img src="{{ $u->avatar_url }}" class="h-full w-full object-cover" alt="Avatar">
        @else
          <div class="h-full w-full flex items-center justify-center text-white/60">👤</div>
        @endif
      </div>
      <div>
        <div class="user-name">{{ $u->name ?? 'Utilizador' }}</div>
        <div class="user-email">{{ $u->email ?? '' }}</div>
      </div>
    </div>
    <form method="POST" action="{{ route('logout') }}">
      @csrf
      <button class="btn-logout" type="submit">
        {{-- ícone: logout --}}
        <svg class="h-4 w-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M15 12H3m12 0-4-4m4 4-4 4M21 5v14a2 2 0 0 1-2 2h-6"/>
        </svg>
        <span>Sair</span>
      </button>
    </form>
  </div>
</aside>
