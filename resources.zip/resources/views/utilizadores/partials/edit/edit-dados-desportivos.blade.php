{{-- VISUALIZAÇÃO --}}
<div id="blocoVisualizacao">
    <div class="bg-light p-3 rounded mb-4">
        <div class="grid grid-cols-12 gap-4 text-sm">
            <div class="col-span-2 text-center">
                @if($dadosDesportivos->arquivo_am_path)
                    <img src="{{ asset('storage/' . $dadosDesportivos->arquivo_am_path) }}" alt="Cartão Federação" class="rounded w-32 h-20 object-cover mx-auto mb-2">
                @else
                    <div class="border rounded w-32 h-20 flex items-center justify-center mx-auto text-xs mb-2">Sem Cartão</div>
                @endif
            </div>

            <div class="col-span-10 grid grid-cols-12 gap-3 text-sm">
                <div class="col-span-2"><strong>Nº Federação:</strong> {{ $dadosDesportivos->numero_federacao }}</div>
                <div class="col-span-2"><strong>Pmb:</strong> {{ $dadosDesportivos->pmb }}</div>
                <div class="col-span-4"><strong>Data Inscrição Clube:</strong> {{ $dadosDesportivos->data_inscricao ? \Carbon\Carbon::parse($dadosDesportivos->data_inscricao)->format('d/m/Y') : '' }}</div>
                <div class="col-span-3"><strong>Escalão:</strong>
                    @forelse($utilizador->escaloes as $es)
                        {{ $es->nome }}
                    @empty
                        -
                    @endforelse
                </div>
                <div class="col-span-3"><strong>Atestado Médico:</strong> {{ $dadosDesportivos->atestado_medico ? 'Sim' : 'Não' }}</div>
                <div class="col-span-4"><strong>Data Atestado Médico:</strong> {{ $dadosDesportivos->data_atestado ? \Carbon\Carbon::parse($dadosDesportivos->data_atestado)->format('d/m/Y') : '' }}</div>
                <div class="col-span-7"><strong>Informações Médicas:</strong> {{ $dadosDesportivos->informacoes_medicas }}</div>
            </div>
        </div>
    </div>
</div>

{{-- EDIÇÃO --}}
<div id="blocoEdicao" class="d-none">
    <div class="bg-light p-3 rounded mb-4">
        <div class="grid grid-cols-12 gap-4 text-sm">
            <div class="col-span-2 text-center">
                @if($dadosDesportivos->arquivo_am_path)
                    <img src="{{ asset('storage/' . $dadosDesportivos->arquivo_am_path) }}" alt="Cartão Federação" class="rounded w-32 h-20 object-cover mx-auto mb-2">
                @else
                    <div class="border rounded w-32 h-20 flex items-center justify-center mx-auto text-xs mb-2">Sem Cartão</div>
                @endif
                <input type="file" name="arquivo_am" class="form-control mt-2">
            </div>

            <div class="col-span-10 grid grid-cols-12 gap-3 text-sm">
                <div class="col-span-2 flex items-center gap-2">
                    <label class="font-bold w-36">Nº Federação:</label>
                    <input type="text" name="numero_federacao" class="form-control" value="{{ old('numero_federacao', $dadosDesportivos->numero_federacao) }}">
                </div>
                <div class="col-span-2 flex items-center gap-2">
                    <label class="font-bold w-12">Pmb:</label>
                    <input type="text" name="pmb" class="form-control" value="{{ old('pmb', $dadosDesportivos->pmb) }}">
                </div>
                <div class="col-span-4 flex items-center gap-2">
                    <label class="font-bold w-44">Data Inscrição Clube:</label>
                    <input type="date" name="data_inscricao" class="form-control" value="{{ old('data_inscricao', $dadosDesportivos->data_inscricao) }}">
                </div>
                <div class="col-span-3 flex items-center gap-2">
                    <label class="font-bold w-24">Escalão:</label>
                    <select name="escalao_ids[]" class="form-control" multiple>
                        <option value="">-- Seleciona --</option>
                        @foreach($escaloes as $escalao)
                            <option value="{{ $escalao->id }}" {{ in_array($escalao->id, $utilizador->escaloes->pluck('id')->toArray()) ? 'selected' : '' }}>
                                {{ $escalao->nome }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-span-3 flex items-center gap-2">
                    <label class="font-bold w-36">Atestado Médico:</label>
                    <select name="atestado_medico" class="form-control">
                        <option value="1" {{ old('atestado_medico', $dadosDesportivos->atestado_medico) == '1' ? 'selected' : '' }}>Sim</option>
                        <option value="0" {{ old('atestado_medico', $dadosDesportivos->atestado_medico) == '0' ? 'selected' : '' }}>Não</option>
                    </select>
                </div>
                <div class="col-span-4 flex items-center gap-2">
                    <label class="font-bold w-44">Data Atestado Médico:</label>
                    <input type="date" name="data_atestado" class="form-control" value="{{ old('data_atestado', $dadosDesportivos->data_atestado) }}">
                </div>
                <div class="col-span-12 flex items-center gap-2">
                    <label class="font-bold w-44">Informações Médicas:</label>
                    <textarea name="informacoes_medicas" class="form-control w-full">{{ old('informacoes_medicas', $dadosDesportivos->informacoes_medicas) }}</textarea>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- TABELAS (sempre visíveis e corretamente dentro da tab) --}}

    <div class="grid grid-cols-12 gap-3 text-sm mt-4">
        <div class="col-span-6">
            <h6 class="font-bold mb-2">Presenças:</h6>
            @include('utilizadores.partials.dados-desportivos.presencas')
        </div>

        <div class="col-span-6">
            <h6 class="font-bold mb-2">Treinos:</h6>
            @include('utilizadores.partials.dados-desportivos.treinos')
        </div>

        <div class="col-span-12 mt-4">
            <h6 class="font-bold mb-2">Resultados:</h6>
            @include('utilizadores.partials.dados-desportivos.resultados')
        </div>
    </div>

