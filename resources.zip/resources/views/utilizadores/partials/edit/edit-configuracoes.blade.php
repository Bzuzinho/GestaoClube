<div class="grid grid-cols-12 gap-4 p-4 text-sm">

    {{-- BLOCO DE VISUALIZAÇÃO --}}
    <div id="blocoVisualizacao" class="col-span-12">
        <div class="grid grid-cols-12 gap-4">

            {{-- RGPD --}}
            <div class="col-span-3">
                <strong>Consentimento RGPD:</strong> {{ $configuracao->consentimento ? 'Sim' : 'Não' }}
            </div>
            <div class="col-span-3">
                <strong>Data Consentimento:</strong>
                {{ optional($configuracao->data_consentimento)->format('d/m/Y') ?? '-' }}
            </div>
            <div class="col-span-3">
                <strong>Ficheiro Consentimento:</strong>
                @if($configuracao->ficheiro_consentimento)
                    <a href="{{ asset('storage/' . $configuracao->ficheiro_consentimento) }}" target="_blank">Ver</a>
                @else
                    -
                @endif
            </div>

            {{-- Transporte --}}
            <div class="col-span-3">
                <strong>Decl. Transporte:</strong> {{ $configuracao->declaracao_transporte ? 'Sim' : 'Não' }}
            </div>
            <div class="col-span-3">
                <strong>Data Transporte:</strong>
                {{ optional($configuracao->data_transporte)->format('d/m/Y') ?? '-' }}
            </div>
            <div class="col-span-3">
                <strong>Ficheiro Transporte:</strong>
                @if($configuracao->ficheiro_transporte)
                    <a href="{{ asset('storage/' . $configuracao->ficheiro_transporte) }}" target="_blank">Ver</a>
                @else
                    -
                @endif
            </div>

            {{-- Afiliação --}}
            <div class="col-span-3">
                <strong>Afiliação:</strong> {{ $configuracao->afiliacao ? 'Sim' : 'Não' }}
            </div>
            <div class="col-span-3">
                <strong>Data Afiliação:</strong>
                {{ optional($configuracao->data_afiliacao)->format('d/m/Y') ?? '-' }}
            </div>
            <div class="col-span-3">
                <strong>Ficheiro Afiliação:</strong>
                @if($configuracao->ficheiro_afiliacao)
                    <a href="{{ asset('storage/' . $configuracao->ficheiro_afiliacao) }}" target="_blank">Ver</a>
                @else
                    -
                @endif
            </div>

            {{-- Perfil (Role) --}}
            <div class="col-span-3">
                <strong>Perfil (Permissões):</strong> {{ ucfirst($utilizador->getRoleNames()->first() ?? '-') }}
            </div>
        </div>
    </div>

    {{-- BLOCO DE EDIÇÃO --}}
    <div id="blocoEdicao" class="col-span-12 d-none">
        <div class="grid grid-cols-12 gap-4">

            {{-- RGPD --}}
            <div class="col-span-3">
                <label class="font-bold">Consentimento RGPD:</label>
                <select name="consentimento" class="form-select">
                    <option value="1" {{ old('consentimento', $configuracao->consentimento) == '1' ? 'selected' : '' }}>Sim</option>
                    <option value="0" {{ old('consentimento', $configuracao->consentimento) == '0' ? 'selected' : '' }}>Não</option>
                </select>
            </div>
            <div class="col-span-3">
                <label class="font-bold">Data Consentimento:</label>
                <input type="date" name="data_consentimento" class="form-control"
                       value="{{ old('data_consentimento', optional($configuracao->data_consentimento)->format('Y-m-d')) }}">
            </div>
            <div class="col-span-3">
                <label class="font-bold">Ficheiro Consentimento:</label>
                <input type="file" name="ficheiro_consentimento" class="form-control">
            </div>

            {{-- Transporte --}}
            <div class="col-span-3">
                <label class="font-bold">Decl. Transporte:</label>
                <select name="declaracao_transporte" class="form-select">
                    <option value="1" {{ old('declaracao_transporte', $configuracao->declaracao_transporte) == '1' ? 'selected' : '' }}>Sim</option>
                    <option value="0" {{ old('declaracao_transporte', $configuracao->declaracao_transporte) == '0' ? 'selected' : '' }}>Não</option>
                </select>
            </div>
            <div class="col-span-3">
                <label class="font-bold">Data Transporte:</label>
                <input type="date" name="data_transporte" class="form-control"
                       value="{{ old('data_transporte', optional($configuracao->data_transporte)->format('Y-m-d')) }}">
            </div>
            <div class="col-span-3">
                <label class="font-bold">Ficheiro Transporte:</label>
                <input type="file" name="ficheiro_transporte" class="form-control">
            </div>

            {{-- Afiliação --}}
            <div class="col-span-3">
                <label class="font-bold">Afiliação:</label>
                <select name="afiliacao" class="form-select">
                    <option value="1" {{ old('afiliacao', $configuracao->afiliacao) == '1' ? 'selected' : '' }}>Sim</option>
                    <option value="0" {{ old('afiliacao', $configuracao->afiliacao) == '0' ? 'selected' : '' }}>Não</option>
                </select>
            </div>
            <div class="col-span-3">
                <label class="font-bold">Data Afiliação:</label>
                <input type="date" name="data_afiliacao" class="form-control"
                       value="{{ old('data_afiliacao', optional($configuracao->data_afiliacao)->format('Y-m-d')) }}">
            </div>
            <div class="col-span-3">
                <label class="font-bold">Ficheiro Afiliação:</label>
                <input type="file" name="ficheiro_afiliacao" class="form-control">
            </div>

          {{-- Perfil (Role) --}}
            <div class="col-span-3">
                <label for="role" class="form-label">Perfil de Permissões</label>

                @if($temPermissaoTotal)
                    <select name="role" id="role" class="form-select">
                        @foreach($rolesDisponiveis as $role)
                            <option value="{{ $role }}" {{ $utilizador->hasRole($role) ? 'selected' : '' }}>
                                {{ ucfirst($role) }}
                            </option>
                        @endforeach
                    </select>
                @else
                    <input type="text" class="form-control" value="{{ ucfirst($utilizador->getRoleNames()->first()) }}" readonly>
                    <input type="hidden" name="role" value="{{ $utilizador->getRoleNames()->first() }}">
                @endif
            </div>
        </div>
    </div>
</div>
