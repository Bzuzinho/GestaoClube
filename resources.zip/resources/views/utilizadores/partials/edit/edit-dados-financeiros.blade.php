<div class="grid grid-cols-12 gap-4 p-4 text-sm">

    {{-- BLOCO DE VISUALIZAÇÃO --}}
    <div id="blocoVisualizacao" class="col-span-12">
        <div class="grid grid-cols-12 gap-4">
            <div class="col-span-4 flex items-center gap-2">
                <label class="font-bold w-36">Mensalidade:</label>
                <span>{{ $utilizador->mensalidade?->designacao ?? '-' }}</span>
            </div>
            <div class="col-span-4 flex items-center gap-2">
                <label class="font-bold w-24">Valor:</label>
                <span>
                    {{ $utilizador->mensalidade?->valor !== null
                        ? '€' . number_format($utilizador->mensalidade->valor, 2, ',', '.')
                        : '€0,00' }}
                </span>
            </div>
            <div class="col-span-4 flex items-center gap-2">
                <label class="font-bold w-36">Conta Corrente:</label>
                <span>€{{ number_format($contaCorrente ?? 0, 2, ',', '.') }}</span>
            </div>
        </div>
    </div>

    {{-- BLOCO DE EDIÇÃO --}}
    <div id="blocoEdicao" class="col-span-12 d-none">
        <div class="grid grid-cols-12 gap-4">
            <div class="col-span-4 flex items-center gap-2">
                <label for="mensalidade_id" class="font-bold w-36">Mensalidade:</label>
                <select name="mensalidade_id" id="mensalidade_id" class="form-select form-select-sm">
                    <option value="">-- Sem mensalidade --</option>
                    @foreach($mensalidades as $mensalidade)
                        <option
                            value="{{ $mensalidade->id }}"
                            data-valor="{{ $mensalidade->valor }}"
                            {{ (old('mensalidade_id', $utilizador->mensalidade_id) == $mensalidade->id) ? 'selected' : '' }}
                        >
                            {{ $mensalidade->designacao }}
                            — €{{ number_format($mensalidade->valor, 2, ',', '.') }}
                        </option>
                    @endforeach
                </select>
            </div>

            <div class="col-span-4 flex items-center gap-2">
                <label class="font-bold w-24">Valor:</label>
                <span id="mensalidade_valor" class="text-sm">
                    {{ $utilizador->mensalidade?->valor !== null
                        ? '€' . number_format($utilizador->mensalidade->valor, 2, ',', '.')
                        : '€0,00' }}
                </span>
            </div>

            <div class="col-span-4 flex items-center gap-2">
                <label class="font-bold w-36">Conta Corrente:</label>
                <span>€{{ number_format($contaCorrente ?? 0, 2, ',', '.') }}</span>
            </div>
        </div>
    </div>

    {{-- TABELA DE FATURAS --}}
    <div class="col-span-12 mt-6">
        <h5 class="font-bold mb-2">Lista Faturas</h5>
        <table class="table table-sm table-bordered w-full text-sm align-middle">
            <thead class="bg-light">
                <tr>
                    <th>Nº Fatura</th>
                    <th>Mês</th>
                    <th>Atleta</th>
                    <th>Valor</th>
                    <th>Estado (Pago)</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                @forelse($utilizador->faturas as $fatura)
                    <tr>
                        <td>{{ $fatura->id }}</td>
                        <td>{{ $fatura->mes }}</td>
                        <td>{{ $utilizador->name }}</td>
                        <td>€{{ number_format($fatura->valor ?? 0, 2, ',', '.') }}</td>
                        <td>{{ (int)$fatura->estado_pagamento === 1 ? 'Pago' : 'Pendente' }}</td>
                        <td>
                            <a href="{{ route('faturas.edit', ['fatura' => $fatura->id, 'tab' => 'dados-financeiros']) }}" class="text-primary">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <a href="{{ route('faturas.show', $fatura->id) }}" class="text-secondary ms-2">
                                <i class="bi bi-eye"></i>
                            </a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="text-center">Sem faturas registadas.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const select = document.getElementById('mensalidade_id');
    const valorSpan = document.getElementById('mensalidade_valor');
    const fmt = new Intl.NumberFormat('pt-PT', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

    if (select && valorSpan) {
        const updateValor = () => {
            const opt = select.options[select.selectedIndex];
            const valor = opt ? parseFloat(opt.getAttribute('data-valor') || '0') : 0;
            valorSpan.textContent = `€${fmt.format(isNaN(valor) ? 0 : valor)}`;
        };

        select.addEventListener('change', updateValor);
        // Atualiza ao carregar, garantindo coerência com o selected
        updateValor();
    }
});
</script>
