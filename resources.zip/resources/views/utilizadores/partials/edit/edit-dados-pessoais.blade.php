<div id="blocoVisualizacao"> 
    <div class="grid grid-cols-12 gap-4 p-4">
        <div class="col-span-2 text-center">
            @if($utilizador->profile_photo_path)
                <img src="{{ asset('storage/' . $utilizador->profile_photo_path) }}" alt="Foto" class="rounded-full w-28 h-28 object-cover mx-auto mb-2">
            @else
                <div class="border rounded-full w-28 h-28 flex items-center justify-center mx-auto text-xs mb-2">Sem Foto</div>
            @endif
        </div>

        <div class="col-span-10 grid grid-cols-12 gap-3 text-sm">
            <div class="col-span-2"><strong>Nº Sócio:</strong> {{ $utilizador->numero_socio }}</div>
            <div class="col-span-2"><strong>NIF:</strong> {{ $utilizador->nif }}</div>
            <div class="col-span-3"><strong>Cartão Cidadão:</strong> {{ $utilizador->cartao_cidadao }}</div>
            <div class="col-span-2"><strong>Menor:</strong> {{ $utilizador->menor ? 'Sim' : 'Não' }}</div>
            <div class="col-span-2"><strong>Estado:</strong> {{ $estados[$utilizador->estado] ?? $utilizador->estado }}</div>

            <div class="col-span-8"><strong>Nome:</strong> {{ $utilizador->name }}</div>
            <div class="col-span-4"><strong>Data Nascimento:</strong> {{ $utilizador->data_nascimento ? \Carbon\Carbon::parse($utilizador->data_nascimento)->format('d-m-Y') : '' }}</div>

            <div class="col-span-6"><strong>Morada:</strong> {{ $utilizador->morada }}</div>
            <div class="col-span-2"><strong>C.P.:</strong> {{ $utilizador->codigo_postal }}</div>
            <div class="col-span-3"><strong>Localidade:</strong> {{ $utilizador->localidade }}</div>
            <div class="col-span-3"><strong>Empresa:</strong> {{ $utilizador->empresa }}</div>
            <div class="col-span-4"><strong>Escola:</strong> {{ $utilizador->escola }}</div>

            <div class="col-span-3"><strong>E. Civil:</strong> {{ $estadoCivil[$utilizador->estado_civil] ?? $utilizador->estado_civil }}</div>
            <div class="col-span-3"><strong>Ocupação:</strong> {{ $utilizador->ocupacao }}</div>
            <div class="col-span-3"><strong>Nacionalidade:</strong> {{ $utilizador->nacionalidade }}</div>
            <div class="col-span-3"><strong>Sexo:</strong> {{ $sexos[$utilizador->sexo] ?? $utilizador->sexo }}</div>

            <div class="col-span-3"><strong>Nº Irmãos:</strong> {{ $utilizador->numero_irmaos }}</div>
            <div class="col-span-3"><strong>Contacto:</strong> {{ $utilizador->contacto }}</div>
            <div class="col-span-4"><strong>Email:</strong> {{ $utilizador->email }}</div>

            <div class="col-span-6"><strong>Tipo de Utilizador:</strong>
                @foreach($utilizador->tipoUsers ?? [] as $tipo)
                    <span class="badge bg-primary me-1">{{ $tipo->nome }}</span>
                @endforeach
            </div>

            @if($utilizador->menor && $utilizador->encarregados->count())
                <div class="col-span-6"><strong>Encarregado(s):</strong>
                    @foreach($utilizador->encarregados as $enc)
                        <span class="badge bg-secondary me-1">{{ $enc->name }}</span>
                    @endforeach
                </div>
            @elseif($utilizador->tipoUsers->contains(fn($tipo) => $tipo->nome === 'Encarregado de Educação'))
                <div class="col-span-6"><strong>Educandos:</strong>
                    @forelse($utilizador->educandos as $edu)
                        <span class="badge bg-secondary me-1">{{ $edu->name }}</span>
                    @empty
                        <span class="text-muted">Nenhum educando associado</span>
                    @endforelse
                </div>
            @endif
        </div>
    </div>
</div>

<div id="blocoEdicao" class="d-none">
    <div class="grid grid-cols-12 gap-4 p-4">
        <div class="col-span-2 text-center">
            @if($utilizador->profile_photo_path)
                <img src="{{ asset('storage/' . $utilizador->profile_photo_path) }}" alt="Foto" class="rounded-full w-28 h-28 object-cover mx-auto mb-2">
            @else
                <div class="border rounded-full w-28 h-28 flex items-center justify-center mx-auto text-xs mb-2">Sem Foto</div>
            @endif
            <input type="file" name="profile_photo_path" class="form-control mt-2">
        </div>

        <div class="col-span-10 grid grid-cols-12 gap-3 text-sm">
            <div class="col-span-2 flex items-center gap-2">
                <label class="font-bold text-sm whitespace-nowrap w-28 text-left">Nº Sócio:</label>
                <span class="text-muted">{{ $utilizador->numero_socio }}</span>
            </div>

            @foreach($campos as $campo)
                <div class="col-span-{{ $campo['span'] }} flex items-center gap-2">
                    <label class="font-bold text-sm whitespace-nowrap w-28 text-left">{{ $campo['label'] }}:</label>
                    @if(isset($campo['type']) && $campo['type'] === 'select')
                        <select name="{{ $campo['name'] }}" class="text-sm font-normal border-0 bg-transparent px-0.5 py-0 focus:ring-0 w-full text-left">
                            @foreach($campo['options'] as $key => $val)
                                <option value="{{ $key }}" {{ (string) old($campo['name'], $utilizador->{$campo['name']}) === (string) $key ? 'selected' : '' }}>{{ $val }}</option>
                            @endforeach
                        </select>
                    @else
                        <input 
                            type="{{ $campo['type'] ?? 'text' }}" 
                            name="{{ $campo['name'] }}" 
                            class="text-sm font-normal border-0 bg-transparent px-0.5 py-0 focus:ring-0 w-full text-left" 
                            value="{{ $campo['name'] === 'data_nascimento' ? old('data_nascimento', $dataNascimento) : old($campo['name'], $utilizador->{$campo['name']}) }}">
                    @endif
                </div>
            @endforeach

            <div class="col-span-6">
                <label class="font-bold text-sm">Tipo de Utilizador:</label>
                <select name="tipo_user[]" multiple class="form-select">
                    @foreach($tiposDisponiveis as $tipo)
                        <option value="{{ $tipo->id }}" {{ in_array($tipo->id, $utilizador->tipoUsers->pluck('id')->toArray() ?? []) ? 'selected' : '' }}>{{ $tipo->nome }}</option>
                    @endforeach
                </select>
            </div>

            @if($utilizador->menor)
                <div class="col-span-6">
                    <label class="font-bold text-sm">Encarregado(s) de Educação:</label>
                    <select name="encarregados[]" multiple class="form-select">
                        @foreach($encarregadosDisponiveis as $enc)
                            <option value="{{ $enc->id }}" {{ in_array($enc->id, $encarregadosSelecionados ?? []) ? 'selected' : '' }}>{{ $enc->name }}</option>
                        @endforeach
                    </select>
                </div>
            @elseif($utilizador->tipoUsers->contains(fn($tipo) => $tipo->nome === 'Encarregado de Educação'))
                <div class="col-span-6">
                    <label class="font-bold text-sm">Educandos:</label>
                    <select name="educandos[]" multiple class="form-select">
                        @foreach($educandosDisponiveis as $edu)
                            <option value="{{ $edu->id }}" {{ in_array($edu->id, $educandosSelecionados ?? []) ? 'selected' : '' }}>{{ $edu->name }}</option>
                        @endforeach
                    </select>
                </div>
            @endif
        </div>
    </div>
</div>
