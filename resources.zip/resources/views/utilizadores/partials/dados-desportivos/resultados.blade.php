@if(isset($utilizador->resultados) && count($utilizador->resultados))
<div class="overflow-x-auto">
    <table class="table table-sm table-bordered w-full text-sm align-middle">
        <thead class="bg-light">
            <tr>
                <th class="whitespace-nowrap">Época</th>
                <th class="whitespace-nowrap">Escalão</th>
                <th class="whitespace-nowrap">Data</th>
                <th class="whitespace-nowrap">Local</th>
                <th class="whitespace-nowrap">Competição</th>
                <th class="whitespace-nowrap">Piscina</th>
                <th class="whitespace-nowrap">Prova</th>
                <th class="whitespace-nowrap">Tempo</th>
            </tr>
        </thead>
        <tbody>
            @foreach($utilizador->resultados as $resultado)
                <tr>
                    <td>{{ $resultado->epoca }}</td>
                    <td>{{ $resultado->escalao }}</td>
                    <td>{{ $resultado->date ? \Carbon\Carbon::parse($resultado->date)->format('d/m/Y') : '' }}</td>
                    <td>{{ $resultado->local }}</td>
                    <td>{{ $resultado->competicao }}</td>
                    <td>{{ $resultado->piscina }}</td>
                    <td>{{ $resultado->prova }}</td>
                    <td>{{ $resultado->tempo }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@else
<p class="text-muted">Sem resultados registados.</p>
@endif
