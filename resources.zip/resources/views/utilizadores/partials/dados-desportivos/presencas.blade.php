<div id="presencas-container" data-user-id="{{ $utilizador->id }}">
    <table class="table table-sm table-bordered w-full text-sm">
        <thead>
            <tr>
                <th>Data</th>
                <th>Nº Treino</th>
                <th>Presença</th>
                <th class="w-24 text-center">Ações</th>
            </tr>
        </thead>
        <tbody id="presencas-body">
            @foreach($utilizador->presencas as $presenca)
                <tr data-id="{{ $presenca->id }}">
                    <td>{{ \Carbon\Carbon::parse($presenca->data)->format('d/m/Y') }}</td>
                    <td>{{ $presenca->numero_treino }}</td>
                    <td>{{ $presenca->presenca ? 'Sim' : 'Não' }}</td>
                    <td class="text-center">
                        <div class="flex justify-center gap-1">
                            <button class="btn btn-sm btn-outline-primary btn-editar-presenca" data-id="{{ $presenca->id }}">
                                <i class="bi bi-pencil"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-danger btn-apagar-presenca" data-id="{{ $presenca->id }}">
                                <i class="bi bi-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <div class="mt-2 text-end">
        <button type="button" class="btn btn-sm btn-outline-success" id="btn-adicionar-presenca">
            <i class="bi bi-plus-circle"></i> Adicionar
        </button>
        <button type="button" class="btn btn-sm btn-outline-primary d-none" id="btn-gravar-todas">
            <i class="bi bi-check-circle"></i> Gravar
        </button>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const btnAdicionar = document.getElementById('btn-adicionar-presenca');
        const btnGravarTodas = document.getElementById('btn-gravar-todas');

        btnAdicionar.addEventListener('click', function (e) {
            e.preventDefault();

            if (document.querySelector('#presencas-body tr[data-id=""]')) return;

            btnAdicionar.classList.add('d-none');
            btnGravarTodas.classList.remove('d-none');

            const novaLinha = `
                <tr data-id="">
                    <td><input type="date" class="form-control form-control-sm" name="data"></td>
                    <td><input type="number" class="form-control form-control-sm" name="numero_treino" min="1"></td>
                    <td>
                        <select class="form-select form-select-sm" name="presenca">
                            <option value="1">Sim</option>
                            <option value="0">Não</option>
                        </select>
                    </td>
                    <td class="text-center">
                        <div class="flex justify-center gap-1">
                            <button type="button" class="btn btn-sm btn-outline-danger btn-apagar-linha" title="Cancelar">
                                <i class="bi bi-x-circle"></i>
                            </button>
                        </div>
                    </td>
                </tr>`;

            document.getElementById('presencas-body').insertAdjacentHTML('beforeend', novaLinha);
        });

        btnGravarTodas.addEventListener('click', function () {
            const linha = document.querySelector('#presencas-body tr[data-editing="true"]') || document.querySelector('#presencas-body tr[data-id=""]');
            if (!linha) return;

            const userId = document.getElementById('presencas-container').dataset.userId;
            const data = linha.querySelector('input[name="data"]').value;
            const numeroTreino = linha.querySelector('input[name="numero_treino"]').value;
            const presenca = linha.querySelector('select[name="presenca"]').value;

            const presencaId = linha.getAttribute('data-id');
            const isEditing = linha.getAttribute('data-editing') === 'true';
            const url = isEditing ? `/presencas/${presencaId}` : "{{ route('presencas.store') }}";
            const method = isEditing ? 'PUT' : 'POST';

            fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: JSON.stringify({
                    _method: method, // importante para PUT
                    user_id: userId,
                    data: data,
                    numero_treino: numeroTreino,
                    presenca: presenca
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.presenca) {
                    linha.setAttribute('data-id', data.presenca.id);
                    linha.removeAttribute('data-editing');
                    linha.innerHTML = `
                        <td>${new Date(data.presenca.data).toLocaleDateString('pt-PT')}</td>
                        <td>${data.presenca.numero_treino}</td>
                        <td>${data.presenca.presenca ? 'Sim' : 'Não'}</td>
                        <td class="text-center">
                            <div class="flex justify-center gap-1">
                                <button class="btn btn-sm btn-outline-primary btn-editar-presenca" data-id="${data.presenca.id}">
                                    <i class="bi bi-pencil"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-danger btn-apagar-presenca" data-id="${data.presenca.id}">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </div>
                        </td>`;

                    btnGravarTodas.classList.add('d-none');
                    btnAdicionar.classList.remove('d-none');
                }
            });
        });

        document.addEventListener('click', function (e) {
            if (e.target.closest('.btn-apagar-linha')) {
                e.preventDefault();
                const linha = e.target.closest('tr');
                linha.remove();
                btnGravarTodas.classList.add('d-none');
                btnAdicionar.classList.remove('d-none');
            }

            if (e.target.closest('.btn-apagar-presenca')) {
                e.preventDefault();
                const id = e.target.closest('button').dataset.id;
                fetch(`/presencas/${id}`, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(res => res.json())
                .then(() => {
                    e.target.closest('tr').remove();
                });
            }

            if (e.target.closest('.btn-editar-presenca')) {
                e.preventDefault();
                const btn = e.target.closest('button');
                const linha = btn.closest('tr');
                const id = btn.dataset.id;
                const dataAtual = linha.children[0].innerText.trim().split('/').reverse().join('-');
                const treinoAtual = linha.children[1].innerText.trim();
                const presencaAtual = linha.children[2].innerText.trim() === 'Sim' ? '1' : '0';

                btnAdicionar.classList.add('d-none');
                btnGravarTodas.classList.remove('d-none');

                linha.setAttribute('data-id', id);
                linha.setAttribute('data-editing', 'true');
                linha.innerHTML = `
                    <td><input type="date" class="form-control form-control-sm" name="data" value="${dataAtual}"></td>
                    <td><input type="number" class="form-control form-control-sm" name="numero_treino" min="1" value="${treinoAtual}"></td>
                    <td>
                        <select class="form-select form-select-sm" name="presenca">
                            <option value="1" ${presencaAtual === '1' ? 'selected' : ''}>Sim</option>
                            <option value="0" ${presencaAtual === '0' ? 'selected' : ''}>Não</option>
                        </select>
                    </td>
                    <td class="text-center">
                        <div class="flex justify-center gap-1">
                            <button type="button" class="btn btn-sm btn-outline-danger btn-apagar-linha" title="Cancelar">
                                <i class="bi bi-x-circle"></i>
                            </button>
                        </div>
                    </td>`;
            }
        });
    });
</script>
