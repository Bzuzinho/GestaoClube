<div id="treinos-container" data-user-id="{{ $utilizador->id }}">
    <table class="table table-sm table-bordered w-full text-sm">
        <thead>
            <tr>
                <th>Nº Treino</th>
                <th>Data</th>
                <th>Sessão</th>
                <th class="w-24 text-center">Ações</th>
            </tr>
        </thead>
        <tbody id="treinos-body">
            @foreach($utilizador->treinos as $treino)
                <tr data-id="{{ $treino->id }}">
                    <td>{{ $treino->numero }}</td>
                    <td>{{ \Carbon\Carbon::parse($treino->data)->format('d/m/Y') }}</td>
                    <td>{{ $treino->sessao }}</td>
                    <td class="text-center">
                        <div class="flex justify-center gap-1">
                            <button class="btn btn-sm btn-outline-primary btn-editar-treino" data-id="{{ $treino->id }}">
                                <i class="bi bi-pencil"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-danger btn-apagar-treino" data-id="{{ $treino->id }}">
                                <i class="bi bi-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <div class="mt-2 text-end">
        <button type="button" class="btn btn-sm btn-outline-success" id="btn-adicionar-treino">
            <i class="bi bi-plus-circle"></i> Adicionar
        </button>
        <button type="button" class="btn btn-sm btn-outline-primary d-none" id="btn-gravar-treino">
            <i class="bi bi-check-circle"></i> Gravar
        </button>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const btnAdd = document.getElementById('btn-adicionar-treino');
        const btnSave = document.getElementById('btn-gravar-treino');
        const tbody = document.getElementById('treinos-body');
        let linhaEmEdicao = null;

        btnAdd.addEventListener('click', function (e) {
            e.preventDefault();
            if (linhaEmEdicao) return;

            btnAdd.classList.add('d-none');
            btnSave.classList.remove('d-none');

            const novaLinha = document.createElement('tr');
            novaLinha.innerHTML = `
                <td><input type="number" name="numero" class="form-control form-control-sm" min="1"></td>
                <td><input type="date" name="data" class="form-control form-control-sm"></td>
                <td><input type="number" name="sessao" class="form-control form-control-sm" min="1"></td>
                <td class="text-center">
                    <div class="flex justify-center gap-1">
                        <button type="button" class="btn btn-sm btn-outline-danger btn-cancelar-linha" title="Cancelar">
                            <i class="bi bi-x-circle"></i>
                        </button>
                    </div>
                </td>
            `;
            novaLinha.dataset.id = '';
            tbody.appendChild(novaLinha);
            linhaEmEdicao = novaLinha;
        });

        btnSave.addEventListener('click', function () {
            if (!linhaEmEdicao) return;

            const treinoId = linhaEmEdicao.dataset.id;
            const isEdicao = treinoId !== '';

            const userId = document.getElementById('treinos-container').dataset.userId;
            const numeroTreino = linhaEmEdicao.querySelector('input[name="numero"]').value;
            const data = linhaEmEdicao.querySelector('input[name="data"]').value;
            const sessao = linhaEmEdicao.querySelector('input[name="sessao"]').value;

            const url = isEdicao ? `/treinos/${treinoId}` : "{{ route('treinos.store') }}";
            const method = isEdicao ? 'PUT' : 'POST';

            fetch(url, {
                method: method,
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: JSON.stringify({
                    user_id: userId,
                    numero: numeroTreino,
                    data: data,
                    sessao: sessao
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.treino) {
                    linhaEmEdicao.dataset.id = data.treino.id;
                    linhaEmEdicao.innerHTML = `
                        <td>${data.treino.numero}</td>
                        <td>${new Date(data.treino.data).toLocaleDateString('pt-PT')}</td>
                        <td>${data.treino.sessao}</td>
                        <td class="text-center">
                            <div class="flex justify-center gap-1">
                                <button class="btn btn-sm btn-outline-primary btn-editar-treino" data-id="${data.treino.id}">
                                    <i class="bi bi-pencil"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-danger btn-apagar-treino" data-id="${data.treino.id}">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </div>
                        </td>`;
                    linhaEmEdicao = null;
                    btnSave.classList.add('d-none');
                    btnAdd.classList.remove('d-none');
                }
            });
        });

        document.addEventListener('click', function (e) {
            const cancelarBtn = e.target.closest('.btn-cancelar-linha');
            const editarBtn = e.target.closest('.btn-editar-treino');
            const apagarBtn = e.target.closest('.btn-apagar-treino');

            if (cancelarBtn) {
                cancelarBtn.closest('tr').remove();
                linhaEmEdicao = null;
                btnSave.classList.add('d-none');
                btnAdd.classList.remove('d-none');
            }

            if (apagarBtn) {
                e.preventDefault();
                const id = apagarBtn.dataset.id;
                fetch(`/treinos/${id}`, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                }).then(() => apagarBtn.closest('tr').remove());
            }

            if (editarBtn) {
                e.preventDefault();
                if (linhaEmEdicao) return;

                const linha = editarBtn.closest('tr');
                const id = editarBtn.dataset.id;

                const numero = linha.children[0].textContent.trim();
                const data = linha.children[1].textContent.trim().split('/').reverse().join('-');
                const sessao = linha.children[2].textContent.trim();

                linha.innerHTML = `
                    <td><input type="number" name="numero" class="form-control form-control-sm" value="${numero}"></td>
                    <td><input type="date" name="data" class="form-control form-control-sm" value="${data}"></td>
                    <td><input type="number" name="sessao" class="form-control form-control-sm" value="${sessao}"></td>
                    <td class="text-center">
                        <div class="flex justify-center gap-1">
                            <button type="button" class="btn btn-sm btn-outline-danger btn-cancelar-linha" title="Cancelar">
                                <i class="bi bi-x-circle"></i>
                            </button>
                        </div>
                    </td>`;
                linha.dataset.id = id;
                linhaEmEdicao = linha;

                btnAdd.classList.add('d-none');
                btnSave.classList.remove('d-none');
            }
        });
    });
</script>
