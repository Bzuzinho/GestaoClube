@extends('layouts.app')

@section('content')
<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="mb-0">Ficha de Membro</h4>
        <a href="{{ route('utilizadores.index') }}" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> Voltar
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Membro Nº {{ $utilizador->numero_socio }} | {{ $utilizador->name }}</h5>
        </div>

        <div class="card-body p-4">

            <ul class="nav nav-tabs mb-3" id="showTabs" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" data-bs-toggle="tab" href="#tab1">Dados Pessoais</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#tab2">Dados Desportivos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#tab3">Dados Financeiros</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#tab4">Configuração</a>
                </li>
            </ul>

            <div class="tab-content p-3 border border-top-0 rounded-bottom bg-light">

                <div class="tab-pane fade show active" id="tab1">
                    @include('utilizadores.partials.show.show-dados-pessoais')
                </div>

                <div class="tab-pane fade" id="tab2">
                    @include('utilizadores.partials.show.show-dados-desportivos')
                </div>

                <div class="tab-pane fade" id="tab3">
                    @include('utilizadores.partials.show.show-dados-financeiros')
                </div>

                <div class="tab-pane fade" id="tab4">
                    @include('utilizadores.partials.show.show-configuracoes')
                </div>

            </div>

        </div>
    </div>

</div>
@endsection
