<div class="modal fade" id="modalCreateUser" tabindex="-1" aria-labelledby="modalCreateUserLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-scrollable">
    <div class="modal-content border-0 shadow-lg rounded-4">
      <form action="{{ route('utilizadores.store') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <div class="modal-header bg-primary text-white rounded-top-4">
          <h5 class="modal-title" id="modalCreateUserLabel">
            <i class="bi bi-person-plus me-2"></i> Novo Utilizador
          </h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body bg-light rounded-bottom-4">
          <div class="container-fluid">
            <div class="row g-3">

              {{-- Dados principais --}}
              <div class="col-md-6">
                <label class="form-label">Nome</label>
                <input type="text" name="name" class="form-control" required>
              </div>

              <div class="col-md-6">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" required>
              </div>

              <div class="col-md-6">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required>
              </div>

              <div class="col-md-6">
                <label class="form-label">NIF</label>
                <input type="text" name="nif" class="form-control">
              </div>

              <div class="col-md-6">
                <label class="form-label">Contacto</label>
                <input type="text" name="contacto" class="form-control">
              </div>

              <div class="col-md-6">
                <label class="form-label">Data de Nascimento</label>
                <input type="date" name="data_nascimento" class="form-control">
              </div>

              <div class="col-md-6">
                <label class="form-label">Sexo</label>
                <select name="sexo" class="form-select">
                  <option value="">Selecionar</option>
                  <option value="Masculino">Masculino</option>
                  <option value="Feminino">Feminino</option>
                  <option value="Outro">Outro</option>
                </select>
              </div>

              <div class="col-md-6">
                <label class="form-label">Estado</label>
                <select name="estado_utilizador" class="form-select">
                  <option value="">Selecionar</option>
                  <option value="1">Ativo</option>
                  <option value="2">Inativo</option>
                  <option value="0">Suspenso</option>
                </select>
              </div>

              {{-- Escalões múltiplos --}}
              <div class="col-md-6">
                <label for="escalao_ids" class="form-label">Escalão</label>
                <select name="escalao_ids[]" id="escalao_ids" class="form-select" multiple>
                  @foreach($escaloes as $escalao)
                    <option value="{{ $escalao->id }}">{{ $escalao->nome }}</option>
                  @endforeach
                </select>
              </div>

              {{-- Tipos de utilizador (múltiplos) --}}
              <div class="col-md-6">
                <label for="tipo_user_ids" class="form-label">Tipo de Utilizador</label>
                <select name="tipo_user_ids[]" id="tipo_user_ids" class="form-select" multiple>
                  @foreach($tiposUtilizador as $tipo)
                    <option value="{{ $tipo->id }}">{{ $tipo->nome }}</option>
                  @endforeach
                </select>
              </div>

              {{-- Perfil de permissões (Spatie role) --}}
              <div class="col-md-6">
                <label for="perfil" class="form-label">Perfil de Permissões</label>
                <select name="perfil" id="perfil" class="form-select">
                  <option value="">Selecionar</option>
                  @foreach($perfis as $perfil)
                    <option value="{{ $perfil }}">{{ ucfirst($perfil) }}</option>
                  @endforeach
                </select>
              </div>

              {{-- Upload da foto --}}
              <div class="col-md-12">
                <label class="form-label">Foto de Perfil</label>
                <input type="file" name="profile_photo_path" class="form-control">
              </div>

            </div>
          </div>
        </div>

        <div class="modal-footer bg-light rounded-bottom-4">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-primary">Guardar</button>
        </div>
      </form>
    </div>
  </div>
</div>
