@extends('layouts.app')

@section('content')
<div class="container py-4">
    <div class="row g-4">
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Utilizadores Ativos</h5>
                    <p class="display-6">{{ $totalUtilizadores }}</p>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Atletas Ativos</h5>
                    <p class="display-6">{{ $totalAtletas }}</p>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Mensalidades Pendentes</h5>
                    <p class="display-6">{{ number_format($mensalidadesPendentes, 2, ',', '.') }} €</p>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mt-4">
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Escalões</h5>
                    <ul class="list-group list-group-flush">
                        @foreach($escaloes as $esc)
                            <li class="list-group-item d-flex justify-content-between">
                                <span>{{ $esc->escalao }}</span>
                                <span>{{ $esc->total }}</span>
                            </li>
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Aniversários do Mês</h5>
                    <ul class="list-group list-group-flush">
                        @forelse($aniversariosDia as $user)
                            @php
                                $data = \Carbon\Carbon::parse($user->data_nascimento);
                                $hoje = now();
                                $ehHoje = $data->format('d-m') === $hoje->format('d-m');
                            @endphp
                            <li class="list-group-item d-flex justify-content-between align-items-center
                                @if($ehHoje) bg-warning fw-bold text-dark border border-warning @endif">
                                {{ $user->name }}
                                <span class="badge bg-light text-dark border">
                                    {{ $data->format('d/m/Y') }}
                                    @if($ehHoje) 🎉 Hoje @endif
                                </span>
                            </li>
                        @empty
                            <li class="list-group-item text-muted">Nenhum aniversariante este mês.</li>
                        @endforelse
                    </ul>
                </div>
            </div>
        </div>

    <div class="row g-4 mt-4">
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Atividades Futuras</h5>
                    <ul class="list-group list-group-flush">
                        @foreach($atividades as $atividade)
                            <li class="list-group-item d-flex justify-content-between">
                                <span>{{ $atividade->nome }}</span>
                                <span>{{ $atividade->data->format('d/m/Y') }}</span>
                            </li>
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Total de Encomendas</h5>
                    <p class="display-6">{{ $totalEncomendas }}</p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
