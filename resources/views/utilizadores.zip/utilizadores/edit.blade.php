@extends('layouts.app')

@php
    $tab = request()->get('tab', 'dados-pessoais');
@endphp

@section('content')
<div class="container py-4">
    <div class="d-flex justify-between items-center mb-3">
        <h4 class="mb-0">Ficha de Membro</h4>
        <a href="{{ route('pessoas.utilizadores.index') }}" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> Voltar
        </a>
    </div>

    <div class="bg-primary text-white rounded shadow-sm p-2 ps-4 mb-3">
        <h6 class="mb-0">Membro Nº {{ $utilizador->numero_socio }} | {{ $utilizador->name }}</h6>
    </div>

    <form action="{{ route('pessoas.utilizadores.update', $utilizador->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <ul class="nav nav-tabs mb-3">
            <li class="nav-item">
                <a class="nav-link {{ $tab === 'dados-pessoais' ? 'active' : '' }}" data-bs-toggle="tab" href="#pessoais">Dados Pessoais</a>
            </li>
            <li class="nav-item">
                <a class="nav-link {{ $tab === 'dados-desportivos' ? 'active' : '' }}" data-bs-toggle="tab" href="#desportivos">Dados Desportivos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link {{ $tab === 'dados-financeiros' ? 'active' : '' }}" data-bs-toggle="tab" href="#dados-financeiros">Dados Financeiros</a>
            </li>
            <li class="nav-item">
                <a class="nav-link {{ $tab === 'configuracao' ? 'active' : '' }}" data-bs-toggle="tab" href="#config">Configuração</a>
            </li>
        </ul>

        <div class="tab-content">
            <div class="tab-pane fade {{ $tab === 'dados-pessoais' ? 'show active' : '' }}" id="pessoais">

                @php
                    $campos = [
                        ['label' => 'NIF', 'name' => 'nif', 'span' => 2],
                        ['label' => 'Cartão Cidadão', 'name' => 'cartao_cidadao', 'span' => 3],
                        ['label' => 'Menor', 'name' => 'menor', 'span' => 2, 'type' => 'select', 'options' => ['0' => 'Não', '1' => 'Sim']],
                        ['label' => 'Estado', 'name' => 'estado', 'span' => 2, 'type' => 'select', 'options' => ['1' => 'Ativo', '0' => 'Inativo', '2' => 'Suspenso']],
                        ['label' => 'Nome', 'name' => 'name', 'span' => 8],
                        ['label' => 'Data Nascimento', 'name' => 'data_nascimento', 'span' => 4, 'type' => 'text'],
                        ['label' => 'Morada', 'name' => 'morada', 'span' => 6],
                        ['label' => 'C.P.', 'name' => 'codigo_postal', 'span' => 2],
                        ['label' => 'Localidade', 'name' => 'localidade', 'span' => 3],
                        ['label' => 'Empresa', 'name' => 'empresa', 'span' => 3],
                        ['label' => 'Escola', 'name' => 'escola', 'span' => 4],
                        ['label' => 'Estado Civil', 'name' => 'estado_civil', 'span' => 3, 'type' => 'select', 'options' => ['Solteiro' => 'Solteiro', 'Casado' => 'Casado', 'Divorciado' => 'Divorciado']],
                        ['label' => 'Ocupação', 'name' => 'ocupacao', 'span' => 3],
                        ['label' => 'Nacionalidade', 'name' => 'nacionalidade', 'span' => 3],
                        ['label' => 'Sexo', 'name' => 'sexo', 'span' => 3, 'type' => 'select', 'options' => ['0' => 'Feminino', '1' => 'Masculino', '2' => 'Outro']],
                        ['label' => 'Nº Irmãos', 'name' => 'numero_irmaos', 'span' => 3, 'type' => 'number'],
                        ['label' => 'Contacto', 'name' => 'contacto', 'span' => 3],
                        ['label' => 'Email', 'name' => 'email', 'span' => 4, 'type' => 'email'],
                    ];
                @endphp

                @include('utilizadores.partials.edit.edit-dados-pessoais', [
                    'utilizador' => $utilizador,
                    'tipoUsers' => $tipoUsers ?? [],
                    'tiposDisponiveis' => $tiposDisponiveis ?? [],
                    'encarregadosDisponiveis' => $encarregadosDisponiveis ?? [],
                    'encarregadosSelecionados' => $encarregadosSelecionados ?? [],
                    'educandosDisponiveis' => $educandosDisponiveis ?? [],
                    'educandosSelecionados' => $educandosSelecionados ?? [],
                    'dataNascimento' => old('data_nascimento', $utilizador->data_nascimento ? $utilizador->data_nascimento->format('d-m-Y') : ''),
                    'tab' => $tab
                ])
            </div>

            <div class="tab-pane fade {{ $tab === 'dados-desportivos' ? 'show active' : '' }}" id="desportivos">
                @include('utilizadores.partials.edit.edit-dados-desportivos', [
                    'dadosDesportivos' => $dadosDesportivos,
                    'utilizador' => $utilizador,
                    'escaloes' => $escaloes,
                    'tab' => $tab
                ])
            </div>

            <div class="tab-pane fade {{ $tab === 'dados-financeiros' ? 'show active' : '' }}" id="dados-financeiros">
                @include('utilizadores.partials.edit.edit-dados-financeiros', [
                    'dadosFinanceiros' => $dadosFinanceiros,
                    'tab' => $tab,
                    'utilizador' => $utilizador
                ])
            </div>

            <div class="tab-pane fade {{ $tab === 'configuracao' ? 'show active' : '' }}" id="config">
                @include('utilizadores.partials.edit.edit-configuracoes', [
                    'configuracao' => $configuracao,
                    'rolesDisponiveis' => $rolesDisponiveis,
                    'utilizador' => $utilizador,
                    'tab' => $tab
                ])
            </div>
        </div>

        <div class="sticky-bottom bg-white py-3 mt-4 d-flex justify-content-end gap-2 border-top">
            <button type="button" id="btnEditar" class="btn btn-primary">
                <i class="bi bi-pencil-square"></i> Editar Ficha
            </button>

            <button type="button" id="btnCancelar" class="btn btn-secondary d-none">
                <i class="bi bi-x-circle"></i> Cancelar
            </button>

            <button type="submit" id="btnGuardar" class="btn btn-success d-none">
                <i class="bi bi-save"></i> Guardar
            </button>
        </div>
    </form>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const btnEditar = document.getElementById('btnEditar');
        const btnCancelar = document.getElementById('btnCancelar');
        const btnGuardar = document.getElementById('btnGuardar');

        const blocosVisualizacao = document.querySelectorAll('#blocoVisualizacao');
        const blocosEdicao = document.querySelectorAll('#blocoEdicao');

        if (btnEditar && btnCancelar && btnGuardar) {
            btnEditar.addEventListener('click', function() {
                blocosVisualizacao.forEach(div => div.classList.add('d-none'));
                blocosEdicao.forEach(div => div.classList.remove('d-none'));
                btnEditar.classList.add('d-none');
                btnGuardar.classList.remove('d-none');
                btnCancelar.classList.remove('d-none');
            });

            btnCancelar.addEventListener('click', function() {
                blocosVisualizacao.forEach(div => div.classList.remove('d-none'));
                blocosEdicao.forEach(div => div.classList.add('d-none'));
                btnEditar.classList.remove('d-none');
                btnGuardar.classList.add('d-none');
                btnCancelar.classList.add('d-none');
            });
        }
    });
</script>
@endsection
