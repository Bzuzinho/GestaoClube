@extends('layouts.app')

@section('page_title','Dashboard')
@section('page_subtitle','Gestão de Utilizadores')

@section('content')
<div class="container py-4">
    <div class="d-flex justify-between items-center mb-3">
        <h2 class="page-title">Gestão de Utilizadores</h2>

        {{-- Abre modal carregando o create por AJAX --}}
        <a href="{{ route('pessoas.utilizadores.create') }}"
        data-modal="{{ route('pessoas.utilizadores.create') }}"
        data-title="Novo Utilizador"
        class="btn btn-primary btn-compact">
        Novo Utilizador
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="table-header">
            Lista de Utilizadores
        </div>

        <div class="table-responsive">
            @php
                $estados = [
                    '1' => 'Ativo',
                    '0' => 'Inativo',
                    '2' => 'Suspenso',
                ];
            @endphp
            <table class="table table-sm table-bordered table-compact">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>Estado</th>
                        <th>Escalão</th>
                        <th>Tipo(s) de Membro</th>
                        <th class="acoes">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($utilizadores as $utilizador)
                        <tr>
                            <td>{{ $utilizador->name }}</td>
                            <td>{{ $utilizador->email }}</td>
                            <td>{{ $estados[$utilizador->estado] ?? '-' }}</td>
                            <td>
                                @forelse($utilizador->escaloes ?? [] as $es)
                                    <span class="badge bg-secondary">{{ $es->nome }}</span>
                                @empty
                                    -
                                @endforelse
                            </td>
                            <td>
                                @forelse($utilizador->tipoMembros ?? [] as $tipo)
                                    <span class="badge bg-info">{{ $tipo->nome }}</span>
                                @empty
                                    -
                                @endforelse
                            </td>
                            <td class="text-center">
                                <a href="{{ route('pessoas.utilizadores.edit', $utilizador->id) }}" class="btn btn-outline-primary btn-compact me-1" title="Ver ficha">
                                    <i class="bi bi-eye"></i>
                                </a>

                                @if(auth()->user()->role === 'administrador')
                                    <form method="POST" action="{{ route('pessoas.utilizadores.destroy', $utilizador->id) }}" class="d-inline" onsubmit="return confirm('Tens a certeza que queres apagar este utilizador?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-outline-danger btn-compact" title="Apagar">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        @if($utilizadores->hasPages())
            <div class="card-footer">
                {{ $utilizadores->links() }}
            </div>
        @endif
    </div>
</div>
@endsection

@include('utilizadores.modal-create')
