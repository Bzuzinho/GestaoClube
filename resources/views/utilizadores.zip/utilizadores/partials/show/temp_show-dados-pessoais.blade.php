<div class="grid grid-cols-12 gap-4 p-4">

    <!-- Imagem de Perfil -->
    <div class="col-span-2 text-center">
        @if($utilizador->profile_photo_path)
            <img src="{{ asset('storage/' . $utilizador->profile_photo_path) }}" alt="Foto" class="rounded-full w-28 h-28 object-cover mx-auto mb-2">
        @else
            <div class="border rounded-full w-28 h-28 flex items-center justify-center mx-auto text-xs mb-2">Sem Foto</div>
        @endif
      </div>

    <!-- Dados Pessoais -->
    <div class="col-span-10 grid grid-cols-12 gap-3 text-sm">

        <!-- Primeira linha -->
        <div class="col-span-2"><strong>Nº Sócio</strong>: {{ $utilizador->numero_socio }}</div>
        <div class="col-span-2"><strong>NIF</strong>: {{ $utilizador->nif }}</div>
        <div class="col-span-3"><strong>Cartão Cidadão</strong>: {{ $utilizador->cartao_cidadao }}</div>
        <div class="col-span-2"><strong>Menor</strong>: {{ $utilizador->menor ? 'Sim' : 'Não' }}</div>
        <div class="col-span-2"><strong>Estado</strong>: {{ $utilizador->estado }}</div>

        <!-- Segunda linha -->
        <div class="col-span-8"><strong>Nome</strong>: {{ $utilizador->name }}</div>
        <div class="col-span-4"><strong>Data N.</strong>: {{ $utilizador->data_nascimento }}</div>
        
        <!-- Terceira linha -->
        <div class="col-span-6"><strong>Morada</strong>: {{ $utilizador->morada }}</div>
        <div class="col-span-2"><strong>C.P.</strong>: {{ $utilizador->codigo_postal }}</div>
        <div class="col-span-3"><strong>Localidade</strong>: {{ $utilizador->localidade }}</div>
        <div class="col-span-3"><strong>Empresa</strong>: {{ $utilizador->empresa }}</div>
        <div class="col-span-4"><strong>Escola</strong>: {{ $utilizador->escola }}</div>

        <!-- Quarta linha -->
        <div class="col-span-3"><strong>E. Civil</strong>: {{ $utilizador->estado_civil }}</div>
        <div class="col-span-3"><strong>Ocupação</strong>: {{ $utilizador->ocupacao }}</div>
        <div class="col-span-3"><strong>Nacionalidade</strong>: {{ $utilizador->nacionalidade }}</div>
        <div class="col-span-3"><strong>Menor</strong>: {{ $utilizador->menor ? 'Sim' : 'Não' }}</div>

        <!-- Quinta linha -->
        <div class="col-span-2"><strong>Sexo</strong>: {{ $utilizador->sexo }}</div>
        <div class="col-span-3"><strong>Nº Irmãos</strong>: {{ $utilizador->numero_irmaos }}</div>
        <div class="col-span-3"><strong>Contacto</strong>: {{ $utilizador->contacto }}</div>
        <div class="col-span-4"><strong>Email</strong>: {{ $utilizador->email }}</div>

        <!-- Sexta linha -->
        <div class="col-span-3"><strong>E. Educação</strong>: {{ $utilizador->encarregado_educacao ? 'Sim' : 'Não' }}</div>
        <div class="col-span-5"><strong>Educandos</strong>: {{ $utilizador->encarregados->pluck('name')->implode(', ') ?: 'Nenhum' }}</div>
        <div class="col-span-4"><strong>Tipo de Membro</strong>: {{ $utilizador->tipoMembros->pluck('nome')->implode(', ') }}</div>

    </div>
</div>
